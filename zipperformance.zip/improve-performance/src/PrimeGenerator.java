import java.math.BigInteger;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.IntStream;
import java.util.stream.Collectors;

/**
 * Generates large probable primes of fixed bit length (2000).
 * Performance improvements:
 * - Reuse Random instances (no new Random() per prime).
 * - Use parallel stream to utilize multiple CPU cores.
 * - Use BigInteger.probablePrime directly (avoids extra nextProbablePrime step).
 * - Preserve order deterministically.
 */
public class PrimeGenerator {

    private static final int BIT_LENGTH = 2000;
    private static final boolean PARALLEL = true; // toggle if needed

    /**
     * Generate a list of probable primes.
     * @param size number of primes
     * @return list of probable primes
     */
    public List<BigInteger> getPrimes(int size) {
        System.out.println("About to find " + size + " primes (" + BIT_LENGTH + " bits). Parallel=" + PARALLEL);

        IntStream indexStream = IntStream.range(0, size);
        if (PARALLEL) {
            indexStream = indexStream.parallel();
        }

        // Each thread uses its own ThreadLocalRandom (cheap, no contention)
        List<BigInteger> primes = indexStream
                .mapToObj(i -> BigInteger.probablePrime(BIT_LENGTH, threadRandom()))
                .collect(Collectors.toList());

        System.out.println("Found all " + primes.size() + " primes.");
        return primes;
    }

    /**
     * Obtain a Random for the current thread.
     * ThreadLocalRandom extends Random so it can be used directly.
     */
    private Random threadRandom() {
        return ThreadLocalRandom.current();
    }
}
