import java.math.BigInteger;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        int count = 100;
        if (args.length > 0) {
            try {
                count = Integer.parseInt(args[0]);
            } catch (NumberFormatException ignored) {}
        }

        PrimeGenerator generator = new PrimeGenerator();

        // Warm-up (JIT)
        generator.getPrimes(2);

        long start = System.currentTimeMillis();
        List<BigInteger> results = generator.getPrimes(count);
        long end = System.currentTimeMillis();

        System.out.println("The time taken was " + (end - start) + " ms.");
        System.out.println("First prime: " + results.get(0));
    }
}
